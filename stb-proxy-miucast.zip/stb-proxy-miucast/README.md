# STB Proxy by MIUCAST

Docker-based Live TV proxy for Stalker Portal / Ministra (Stalker Middleware). It fetches only the `type=itv` Live TV catalog, resolves channel commands with the portal's `create_link` API and remuxes the stream to HLS on demand with FFmpeg (`-c copy`, no video transcoding).

## Output URLs

- Admin UI: `http://IP:7702/`
- All portals playlist: `http://IP:7702/stb/playlist.m3u`
- Per-portal playlist: `http://IP:7702/stb/playlist.m3u?portal_id=1`
- Per-channel HLS: `http://IP:7702/stb/mux/########.m3u8` (8-digit random token)
- Health: `http://IP:7702/health`

The generated `.m3u8` URL is a real local HLS playlist. FFmpeg runs only when a player opens a channel and is stopped after the idle timeout. The stability defaults use a 12-segment playlist window, retain additional old segments for slower players, automatically reconnect on transient HTTP/TCP errors, and re-request the portal `create_link` URL when the HLS playlist stops advancing.

## Install (Docker Desktop + WSL / Ubuntu / Linux)

```bash
cp .env.example .env
nano .env
# Change ADMIN_PASSWORD and set PUBLIC_BASE_URL to the address your player can reach.
docker compose up -d --build
```

For example, for a LAN address `192.168.1.188`:

```dotenv
PUBLIC_BASE_URL=http://192.168.1.188:7702
```

Open `http://192.168.1.188:7702/`, sign in with `ADMIN_USER` and `ADMIN_PASSWORD` from `.env`, add a portal, then click **Fetch Live TV**. The portal URL may be a base URL or an endpoint path such as `/stalker_portal`, `/stalker_portal/c/`, `/portal.php`, or `/server/load.php`.

## Portal authentication modes

- **MAC mode:** enter a valid MAC such as `00:1A:79:XX:XX:XX`; Stalker handshakes and API requests use that identity.
- **Stalker / Ministra login-password mode:** leave MAC blank and enter both subscriber login and password. The proxy creates a persistent MAG-like client MAC and uses the portal `get_profile` / `do_auth` second-step when the portal requests it. Ministra must be configured to allow the login/password flow; a strict portal may require additional device ID/signature settings or a provider-specific adapter. Reusing an account may displace an earlier device on portals configured for single-device authorization.
- **HTTP Basic Auth (optional):** separate username/password fields for web servers that protect the portal URL with HTTP Basic authentication. These credentials do not replace subscriber authentication.

Use only portals and subscriber credentials you are authorized to access.

## Notes / troubleshooting

- This implementation requests the Live TV catalog only (`type=itv`, `action=get_all_channels`). It does not query VOD or series endpoints.
- The stream is remuxed with stream copy. It does not decrypt DRM, bypass portal authorization, or transcode unsupported codecs. Some portal-specific APIs, nonstandard `create_link` responses, or DRM-protected streams need provider-specific integration.
- If fetch fails, review `docker compose logs -f stb-proxy` and verify portal path, account/MAC, network reachability, and any HTTP Basic Auth credentials.
- If a channel times out or freezes every 20–30 seconds, rebuild with `docker compose up -d --build`. This version adds FFmpeg HTTP reconnection, a wider HLS window (`HLS_LIST_SIZE=12`, `HLS_DELETE_THRESHOLD=8`), and an automatic stale-playlist watchdog that re-resolves `create_link` when a stream stops advancing. The watchdog can cause a brief recovery pause while the portal issues a fresh URL. If the issue continues, inspect `docker compose logs -f stb-proxy`; the portal may invalidate device sessions, require provider-specific headers, or terminate the source stream.
- Stability environment options: `HLS_TIME` (segment target in seconds), `HLS_LIST_SIZE` (minimum 8), `HLS_DELETE_THRESHOLD` (minimum 4), and `STREAM_STALE_SECONDS` (playlist stall threshold). Change them in `.env`, then run `docker compose up -d --build`.
- Do not enable reconnect on all 4xx HTTP status codes: a 401/403 may mean the provider's URL or session expired, so the proxy should fetch a fresh `create_link` instead of repeatedly retrying the same rejected URL.
- Persistent portal/channel configuration and credentials live in the Docker named volume `stb-data` at `/data/stb-proxy.sqlite3`; generated HLS segments are temporary under `/data/hls/`. Protect this volume and its backups.
- Admin pages/API use HTTP Basic Auth. Stream URLs are token-based and do not require Basic Auth, because IPTV clients need to fetch them directly. Do not expose the service to the public internet without a firewall/VPN or HTTPS reverse proxy.

import html
import hashlib
import json
import os
import re
import secrets
import shutil
import sqlite3
import subprocess
import threading
import time
from contextlib import contextmanager
from pathlib import Path
from urllib.parse import urlsplit, urlunsplit, urljoin

import requests
from fastapi import Depends, FastAPI, HTTPException, Request
from fastapi.responses import HTMLResponse, PlainTextResponse, Response
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field

APP_NAME = "STB Proxy by MIUCAST"
PORT = int(os.getenv("PORT", "7702"))
DB_PATH = Path(os.getenv("DB_PATH", "/data/stb-proxy.sqlite3"))
DATA_DIR = Path(os.getenv("DATA_DIR", "/data"))
HLS_ROOT = DATA_DIR / "hls"
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", f"http://127.0.0.1:{PORT}").rstrip("/")
ADMIN_USER = os.getenv("ADMIN_USER", "admin")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "change-this-password")
FFMPEG_BIN = os.getenv("FFMPEG_BIN", "ffmpeg")
MAX_PAGES = max(1, min(int(os.getenv("MAX_PAGES", "100")), 500))
IDLE_SECONDS = max(60, int(os.getenv("IDLE_SECONDS", "180")))
START_WAIT_SECONDS = max(5, min(int(os.getenv("START_WAIT_SECONDS", "25")), 90))
# Stability controls for Live TV remuxing. Keep enough HLS history for slower IPTV clients.
HLS_TIME = max(2, min(int(os.getenv("HLS_TIME", "4")), 10))
HLS_LIST_SIZE = max(8, min(int(os.getenv("HLS_LIST_SIZE", "12")), 30))
HLS_DELETE_THRESHOLD = max(4, min(int(os.getenv("HLS_DELETE_THRESHOLD", "8")), 30))
STREAM_STALE_SECONDS = max(10, min(int(os.getenv("STREAM_STALE_SECONDS", "18")), 180))
SEGMENT_RETENTION_SECONDS = max(120, HLS_TIME * (HLS_LIST_SIZE + HLS_DELETE_THRESHOLD + 2))

DB_PATH.parent.mkdir(parents=True, exist_ok=True)
HLS_ROOT.mkdir(parents=True, exist_ok=True)

app = FastAPI(title=APP_NAME, docs_url=None, redoc_url=None, openapi_url=None)
security = HTTPBasic(auto_error=False)

# Live-only stream workers. A worker exists only while a player is accessing its HLS URL.
stream_workers = {}
worker_lock = threading.RLock()
portal_tokens = {}  # portal_id -> {token, endpoint, expires}
token_lock = threading.RLock()
UA = "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG254 Safari/533.3"


class PortalIn(BaseModel):
    name: str = Field(min_length=1, max_length=100)
    url: str = Field(min_length=4, max_length=2048)
    mac: str = Field(default="", max_length=32)
    username: str = Field(default="", max_length=200)
    password: str = Field(default="", max_length=500)
    http_username: str = Field(default="", max_length=200)
    http_password: str = Field(default="", max_length=500)


@contextmanager
def db():
    conn = sqlite3.connect(DB_PATH, timeout=30)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    with db() as conn:
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS portals (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            url TEXT NOT NULL,
            mac TEXT NOT NULL DEFAULT '',
            username TEXT NOT NULL DEFAULT '',
            password TEXT NOT NULL DEFAULT '',
            http_username TEXT NOT NULL DEFAULT '',
            http_password TEXT NOT NULL DEFAULT '',
            mac_generated INTEGER NOT NULL DEFAULT 0,
            endpoint TEXT NOT NULL DEFAULT '',
            created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS channels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            portal_id INTEGER NOT NULL REFERENCES portals(id) ON DELETE CASCADE,
            channel_id TEXT NOT NULL,
            name TEXT NOT NULL,
            logo TEXT NOT NULL DEFAULT '',
            group_title TEXT NOT NULL DEFAULT 'Live TV',
            cmd TEXT NOT NULL,
            token TEXT NOT NULL UNIQUE,
            updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(portal_id, channel_id)
        );
        CREATE INDEX IF NOT EXISTS idx_channels_portal ON channels(portal_id);
        CREATE INDEX IF NOT EXISTS idx_channels_token ON channels(token);
        """)
        # Safe additive migrations for an existing local database.
        portal_columns = {row[1] for row in conn.execute("PRAGMA table_info(portals)").fetchall()}
        for column, definition in [
            ("http_username", "TEXT NOT NULL DEFAULT ''"),
            ("http_password", "TEXT NOT NULL DEFAULT ''"),
            ("mac_generated", "INTEGER NOT NULL DEFAULT 0"),
        ]:
            if column not in portal_columns:
                conn.execute(f"ALTER TABLE portals ADD COLUMN {column} {definition}")


@app.on_event("startup")
def startup():
    init_db()
    threading.Thread(target=worker_cleanup_loop, daemon=True, name="stb-worker-cleanup").start()


def admin_auth(credentials: HTTPBasicCredentials = Depends(security)):
    import secrets as _secrets
    valid_user = credentials is not None and _secrets.compare_digest(credentials.username, ADMIN_USER)
    valid_password = credentials is not None and _secrets.compare_digest(credentials.password, ADMIN_PASSWORD)
    if not (valid_user and valid_password):
        from fastapi import status
        from fastapi.responses import JSONResponse
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required", headers={"WWW-Authenticate": "Basic"})
    return credentials.username


def normalize_portal_url(value: str) -> str:
    value = value.strip()
    parsed = urlsplit(value)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise HTTPException(status_code=400, detail="Portal URL must start with http:// or https://")
    if parsed.username or parsed.password:
        raise HTTPException(status_code=400, detail="Put portal credentials in the form fields, not in the URL")
    # Keep a supplied API endpoint path, but remove query/fragment.
    return urlunsplit((parsed.scheme, parsed.netloc, parsed.path.rstrip("/"), "", ""))


def get_portal(portal_id: int):
    with db() as conn:
        row = conn.execute("SELECT * FROM portals WHERE id=?", (portal_id,)).fetchone()
    if not row:
        raise HTTPException(status_code=404, detail="Portal not found")
    return dict(row)


def _candidate_endpoints(portal_url: str):
    p = urlsplit(portal_url)
    path = p.path.rstrip("/")
    if path.endswith(".php"):
        supplied = urlunsplit((p.scheme, p.netloc, path, "", ""))
        roots = [path.rsplit("/", 1)[0]]
        candidates = [supplied]
    else:
        if path.endswith("/c"):
            path = path[:-2]
        roots = [path]
        candidates = []
    for root in list(roots):
        candidates.extend([
            f"{root}/server/load.php",
            f"{root}/portal.php",
            f"{root}/c/portal.php",
            f"{root}/c/",
        ])
        if root.endswith("/stalker_portal"):
            candidates.extend([f"{root}/c/portal.php", f"{root}/c/"])
    candidates.extend([
        "/stalker_portal/server/load.php",
        "/stalker_portal/portal.php",
        "/stalker_portal/c/portal.php",
        "/portal.php",
        "/server/load.php",
        "/c/portal.php",
        "/c/",
    ])
    out = []
    for candidate in candidates:
        if candidate.startswith("http://") or candidate.startswith("https://"):
            url = candidate
        else:
            url = urlunsplit((p.scheme, p.netloc, candidate if candidate.startswith("/") else "/" + candidate, "", ""))
        if url not in out:
            out.append(url)
    return out


def _headers(portal):
    mac = (portal.get("mac") or "").strip()
    cookie_parts = []
    if mac:
        cookie_parts.append(f"mac={mac}")
    cookie_parts.extend(["stb_lang=en", "timezone=Asia%2FBangkok"])
    return {
        "User-Agent": UA,
        "X-User-Agent": "Model: MAG254; Link: Ethernet",
        "Accept": "*/*",
        "Connection": "keep-alive",
        "Cookie": "; ".join(cookie_parts),
    }


def _http_basic_auth(portal):
    if portal.get("http_username"):
        return (portal["http_username"], portal.get("http_password", ""))
    return None


def _request(portal, endpoint, params, timeout=(6, 20)):
    response = requests.get(endpoint, params=params, headers=_headers(portal), auth=_http_basic_auth(portal), timeout=timeout, allow_redirects=True)
    response.raise_for_status()
    try:
        return response.json()
    except ValueError:
        excerpt = response.text[:180].replace("\n", " ")
        raise RuntimeError(f"Portal API did not return JSON (HTTP {response.status_code}): {excerpt}")


def _js_obj(payload):
    if isinstance(payload, dict):
        js = payload.get("js", payload)
        if isinstance(js, str):
            try:
                js = json.loads(js)
            except Exception:
                pass
        return js
    return payload


def _device_identity(portal):
    """Stable MAG-like identity used by get_profile/do_auth for this proxy instance."""
    seed = (portal.get("url", "") + "|" + portal.get("mac", "")).encode("utf-8")
    d1 = hashlib.sha256(seed + b"|device_id_1").hexdigest().upper()
    d2 = hashlib.sha256(seed + b"|device_id_2").hexdigest().upper()
    serial = hashlib.sha256(seed + b"|serial").hexdigest()[:13].upper()
    return d1, d2, serial


def _profile_params(portal, auth_second_step="0"):
    device_id, device_id2, serial = _device_identity(portal)
    metrics = {"mac": portal.get("mac", ""), "model": "MAG254", "type": "STB", "uid": "", "device": "", "random": ""}
    return {
        "type": "stb", "action": "get_profile", "hd": "1",
        "ver": "ImageDescription: 0.2.18-r14-pub-250; PORTAL version: 5.5.0; API Version: 328",
        "num_banks": "2", "sn": serial, "stb_type": "MAG254", "client_type": "STB",
        "image_version": "218", "video_out": "hdmi", "device_id": device_id,
        "device_id2": device_id2, "signature": "", "auth_second_step": auth_second_step,
        "hw_version": "1.7-BD00", "not_valid_token": "0", "metrics": json.dumps(metrics, separators=(",", ":")),
        "hw_version_2": "1.7-BD00", "api_signature": "", "prehash": "", "JsHttpRequest": "1-xml",
    }


def _request_with_token(portal, endpoint, token, params, method="GET"):
    headers = _headers(portal)
    headers["Authorization"] = f"Bearer {token}"
    basic = _http_basic_auth(portal)
    if method == "POST":
        response = requests.post(endpoint, data=params, headers=headers, auth=basic, timeout=(6, 20), allow_redirects=True)
    else:
        response = requests.get(endpoint, params=params, headers=headers, auth=basic, timeout=(6, 20), allow_redirects=True)
    response.raise_for_status()
    try:
        return response.json()
    except ValueError:
        excerpt = response.text[:160].replace("\n", " ")
        raise RuntimeError(f"Stalker authentication response was not JSON: {excerpt}")


def _profile_status(payload):
    js = _js_obj(payload)
    if not isinstance(js, dict):
        return None, ""
    status = js.get("status")
    try:
        status = int(status) if status is not None else None
    except (ValueError, TypeError):
        pass
    message = str(js.get("message", js.get("error", "")) or "")
    return status, message


def _bootstrap_login(portal, endpoint, token):
    # A classic MAC-authorized portal does not need do_auth. Ministra can request
    # a second login/password step, indicated by get_profile status=2.
    if not (portal.get("username") and portal.get("password")):
        return token
    profile_payload = _request_with_token(portal, endpoint, token, _profile_params(portal, "0"))
    status, message = _profile_status(profile_payload)
    if status == 1:
        raise RuntimeError("Portal refused this STB profile (blocked device or invalid device identity). " + message[:180])
    needs_login = status == 2 or "login" in message.lower() and "password" in message.lower()
    if needs_login:
        device_id, device_id2, _ = _device_identity(portal)
        auth_params = {
            "type": "stb", "action": "do_auth", "login": portal["username"],
            "password": portal["password"], "device_id": device_id, "device_id2": device_id2,
            "JsHttpRequest": "1-xml",
        }
        auth_payload = _request_with_token(portal, endpoint, token, auth_params, method="POST")
        auth_js = _js_obj(auth_payload)
        authenticated = auth_js is True or (isinstance(auth_js, str) and auth_js.strip().lower() in ("true", "1", "ok", "success"))
        if isinstance(auth_js, dict):
            auth_status = auth_js.get("status")
            authenticated = auth_js.get("success") is True or str(auth_status).lower() in ("0", "ok", "success")
        # Some legacy portals only implement the original GET form of do_auth.
        if not authenticated:
            try:
                auth_payload = _request_with_token(portal, endpoint, token, auth_params, method="GET")
                auth_js = _js_obj(auth_payload)
                authenticated = auth_js is True or (isinstance(auth_js, str) and auth_js.strip().lower() in ("true", "1", "ok", "success"))
                if isinstance(auth_js, dict):
                    authenticated = auth_js.get("success") is True or str(auth_js.get("status", "")).lower() in ("0", "ok", "success")
            except Exception:
                authenticated = False
        if not authenticated:
            raise RuntimeError("Stalker login/password authentication failed. Verify credentials and whether this portal allows do_auth.")
        second_payload = _request_with_token(portal, endpoint, token, _profile_params(portal, "1"))
        second_status, second_message = _profile_status(second_payload)
        if second_status in (1, 2):
            raise RuntimeError("Portal did not accept the login/password second step. " + second_message[:180])
    # Refresh the bearer token when supported. If this portal leaves it unchanged,
    # retain the original token.
    try:
        refreshed = _request(portal, endpoint, {
            "type": "stb", "action": "handshake", "token": token, "JsHttpRequest": "1-xml",
        }, timeout=(4, 8))
        refresh_js = _js_obj(refreshed)
        if isinstance(refresh_js, dict) and refresh_js.get("token"):
            return str(refresh_js["token"])
    except Exception:
        pass
    return token


def _handshake(portal):
    last_error = "No compatible Stalker API endpoint responded"
    for endpoint in _candidate_endpoints(portal["url"]):
        try:
            payload = _request(portal, endpoint, {
                "type": "stb", "action": "handshake", "token": "", "prehash": "0",
                "JsHttpRequest": "1-xml",
            }, timeout=(4, 8))
            js = _js_obj(payload)
            token = js.get("token") if isinstance(js, dict) else None
            if token:
                token = _bootstrap_login(portal, endpoint, str(token))
                with db() as conn:
                    conn.execute("UPDATE portals SET endpoint=? WHERE id=?", (endpoint, portal["id"]))
                with token_lock:
                    portal_tokens[portal["id"]] = {"token": str(token), "endpoint": endpoint, "expires": time.time() + 480}
                return endpoint, str(token)
            last_error = f"No handshake token from {endpoint}"
        except Exception as exc:
            last_error = f"{endpoint}: {str(exc)[:160]}"
    raise RuntimeError("Stalker handshake failed. Check portal URL, MAC, network, and credentials. Last error: " + last_error)


def _get_token(portal, force=False):
    with token_lock:
        cached = portal_tokens.get(portal["id"])
        if cached and not force and cached["expires"] > time.time() + 20:
            return cached["endpoint"], cached["token"]
    # If we already know the endpoint, try it first on refresh.
    if portal.get("endpoint"):
        try:
            payload = _request(portal, portal["endpoint"], {
                "type": "stb", "action": "handshake", "token": "", "prehash": "0", "JsHttpRequest": "1-xml",
            }, timeout=(4, 8))
            js = _js_obj(payload)
            token = js.get("token") if isinstance(js, dict) else None
            if token:
                token = _bootstrap_login(portal, portal["endpoint"], str(token))
                with token_lock:
                    portal_tokens[portal["id"]] = {"token": str(token), "endpoint": portal["endpoint"], "expires": time.time() + 480}
                return portal["endpoint"], str(token)
        except Exception:
            pass
    return _handshake(portal)


def portal_api(portal, params, retry=True):
    endpoint, token = _get_token(portal)
    p = dict(params)
    p.setdefault("JsHttpRequest", "1-xml")
    headers = _headers(portal)
    headers["Authorization"] = f"Bearer {token}"
    try:
        response = requests.get(endpoint, params=p, headers=headers, auth=_http_basic_auth(portal), timeout=(6, 25))
        if response.status_code == 401 and retry:
            with token_lock:
                portal_tokens.pop(portal["id"], None)
            return portal_api(portal, params, retry=False)
        response.raise_for_status()
        try:
            return response.json()
        except ValueError:
            raise RuntimeError(f"Portal API response was not JSON (HTTP {response.status_code})")
    except requests.RequestException as exc:
        raise RuntimeError(f"Portal API request failed: {exc}") from exc

def _data_list(payload):
    js = _js_obj(payload)
    if isinstance(js, list):
        return js
    if isinstance(js, dict):
        data = js.get("data", js.get("channels", []))
        if isinstance(data, dict):
            data = data.get("data", [])
        return data if isinstance(data, list) else []
    return []


def _id_string(item):
    value = item.get("id", item.get("ch_id", item.get("channel_id", "")))
    return str(value).strip() if value is not None else ""


def fetch_live_channels(portal_id: int):
    portal = get_portal(portal_id)
    # Make sure authentication and endpoint work before mutating channel data.
    _get_token(portal)
    genres = {}
    try:
        for g in _data_list(portal_api(portal, {"type": "itv", "action": "get_genres"})):
            gid = str(g.get("id", ""))
            genres[gid] = str(g.get("title", g.get("name", "Live TV")))
    except Exception:
        pass

    gathered = {}
    for page in range(1, MAX_PAGES + 1):
        payload = portal_api(portal, {"type": "itv", "action": "get_all_channels", "p": page})
        items = _data_list(payload)
        if not items:
            break
        for item in items:
            if not isinstance(item, dict):
                continue
            channel_id = _id_string(item)
            name = str(item.get("name", item.get("title", ""))).strip()
            cmd = str(item.get("cmd", item.get("url", ""))).strip()
            if not channel_id or not name or not cmd:
                continue
            # This endpoint is the Live TV (itv) catalog only. Never query VOD/series.
            genre_id = str(item.get("tv_genre_id", item.get("genre_id", "")))
            group = genres.get(genre_id, str(item.get("genre_title", "Live TV")) or "Live TV")
            gathered[channel_id] = {
                "channel_id": channel_id,
                "name": name,
                "logo": str(item.get("logo", item.get("icon", "")) or ""),
                "group_title": group or "Live TV",
                "cmd": cmd,
            }
        # A short page usually indicates the final page.
        if len(items) < 10:
            break

    if not gathered:
        raise RuntimeError("Handshake succeeded, but no Live TV channels were returned. The portal may use a custom API format or reject this MAC.")

    with db() as conn:
        existing = {row["channel_id"]: row["token"] for row in conn.execute(
            "SELECT channel_id, token FROM channels WHERE portal_id=?", (portal_id,)
        ).fetchall()}
        for channel_id, channel in gathered.items():
            token = existing.get(channel_id) or _new_token(conn)
            conn.execute("""
                INSERT INTO channels(portal_id, channel_id, name, logo, group_title, cmd, token, updated_at)
                VALUES(?,?,?,?,?,?,?,CURRENT_TIMESTAMP)
                ON CONFLICT(portal_id, channel_id) DO UPDATE SET
                  name=excluded.name, logo=excluded.logo, group_title=excluded.group_title,
                  cmd=excluded.cmd, updated_at=CURRENT_TIMESTAMP
            """, (portal_id, channel_id, channel["name"], channel["logo"], channel["group_title"], channel["cmd"], token))
        # A temp table avoids SQLite's bind-parameter limit on portals with 1,000+ channels.
        conn.execute("CREATE TEMP TABLE IF NOT EXISTS seen_channels (channel_id TEXT PRIMARY KEY)")
        conn.execute("DELETE FROM seen_channels")
        conn.executemany("INSERT OR IGNORE INTO seen_channels(channel_id) VALUES(?)",
                         [(channel_id,) for channel_id in gathered.keys()])
        conn.execute("DELETE FROM channels WHERE portal_id=? AND channel_id NOT IN (SELECT channel_id FROM seen_channels)",
                     (portal_id,))
    return len(gathered)


def _new_token(conn):
    for _ in range(500):
        value = str(secrets.randbelow(90_000_000) + 10_000_000)  # 8 numeric digits
        if not conn.execute("SELECT 1 FROM channels WHERE token=?", (value,)).fetchone():
            return value
    raise RuntimeError("Unable to allocate a unique stream token")


def safe_public_portal(row):
    return {"id": row["id"], "name": row["name"], "url": row["url"], "mac": row["mac"],
            "mac_generated": bool(row["mac_generated"]), "username": row["username"],
            "has_password": bool(row["password"]), "http_basic_enabled": bool(row["http_username"]),
            "endpoint": row["endpoint"]}


def channel_to_dict(row):
    return {
        "id": row["id"], "portal_id": row["portal_id"], "portal_name": row["portal_name"] if "portal_name" in row.keys() else "",
        "channel_id": row["channel_id"], "name": row["name"], "logo": row["logo"],
        "group_title": row["group_title"], "token": row["token"],
        "url": f"{PUBLIC_BASE_URL}/stb/mux/{row['token']}.m3u8",
    }


def list_channels(portal_id=None):
    with db() as conn:
        if portal_id is None:
            rows = conn.execute("SELECT c.*, p.name AS portal_name FROM channels c JOIN portals p ON p.id=c.portal_id ORDER BY p.name, c.group_title, c.name").fetchall()
        else:
            rows = conn.execute("SELECT c.*, p.name AS portal_name FROM channels c JOIN portals p ON p.id=c.portal_id WHERE c.portal_id=? ORDER BY c.group_title, c.name", (portal_id,)).fetchall()
    return [channel_to_dict(row) for row in rows]


def _resolve_stream_url(portal, channel_cmd):
    payload = portal_api(portal, {
        "type": "itv", "action": "create_link", "cmd": channel_cmd,
        "forced_storage": "undefined", "disable_ad": "0", "download": "0",
    })
    js = _js_obj(payload)
    cmd = ""
    if isinstance(js, dict):
        cmd = str(js.get("cmd", js.get("url", js.get("link", ""))) or "").strip()
    elif isinstance(js, str):
        cmd = js.strip()
    if not cmd:
        raise RuntimeError("Portal create_link returned no stream URL")
    # Common Stalker command prefixes; the actual URL can also be embedded after a prefix.
    cmd = re.sub(r"^(?:(?:ffmpeg|auto|ffrt|wget)\s+)+", "", cmd, flags=re.IGNORECASE).strip().strip("'\"")
    match = re.search(r"https?://[^\s'\"]+", cmd)
    if match:
        stream_url = match.group(0).rstrip(";,)")
    elif cmd.startswith("/"):
        endpoint = portal.get("endpoint") or portal["url"]
        stream_url = urljoin(endpoint, cmd)
    else:
        raise RuntimeError("Portal create_link returned an unsupported URL format")
    if urlsplit(stream_url).scheme not in ("http", "https"):
        raise RuntimeError("Resolved stream URL must use HTTP or HTTPS")
    return stream_url


def _stop_worker(worker):
    """Stop one FFmpeg process and close its log without leaving zombies."""
    process = worker.get("process")
    if process is not None and process.poll() is None:
        try:
            process.terminate()
            process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            process.kill()
            try:
                process.wait(timeout=3)
            except subprocess.TimeoutExpired:
                pass
        except Exception:
            pass
    try:
        worker.get("log").close()
    except Exception:
        pass


def _worker_output_stale(worker):
    """True when a live worker has stopped advancing its HLS playlist."""
    now_mono = time.monotonic()
    started_at = worker.get("started_at", now_mono)
    age_since_start = now_mono - started_at
    # Allow normal startup time before evaluating a playlist that is not ready yet.
    startup_grace = max(START_WAIT_SECONDS + 5, STREAM_STALE_SECONDS * 2)
    playlist = worker["out_dir"] / "index.m3u8"
    try:
        playlist_age = max(0.0, time.time() - playlist.stat().st_mtime)
    except OSError:
        return age_since_start > startup_grace
    # Once a playlist has been produced, judge its update age immediately; do not
    # mask a freeze just because the FFmpeg process is relatively young.
    return playlist_age > STREAM_STALE_SECONDS


def _purge_old_segments(out_dir):
    """Bound disk usage after a worker is restarted while keeping a short client buffer."""
    cutoff = time.time() - SEGMENT_RETENTION_SECONDS
    try:
        for segment in out_dir.glob("segment_*.ts"):
            try:
                if segment.stat().st_mtime < cutoff:
                    segment.unlink(missing_ok=True)
            except OSError:
                pass
    except OSError:
        pass


def _worker_for(token):
    with worker_lock:
        worker = stream_workers.get(token)
        preserve_existing_segments = False
        if worker and worker["process"].poll() is None and not _worker_output_stale(worker):
            worker["last_access"] = time.monotonic()
            return worker
        if worker:
            # A dead/stalled FFmpeg process often indicates a short-lived upstream
            # create_link URL. Re-resolve the portal URL on the next start, while
            # keeping recent TS files briefly for players still requesting them.
            preserve_existing_segments = True
            stream_workers.pop(token, None)
            _stop_worker(worker)

        with db() as conn:
            row = conn.execute("SELECT c.*, p.name AS portal_name FROM channels c JOIN portals p ON p.id=c.portal_id WHERE c.token=?", (token,)).fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Unknown stream token. Fetch Live TV again from the admin panel.")
        channel = dict(row)
        portal = get_portal(channel["portal_id"])
        try:
            # create_link is called every time FFmpeg is restarted, refreshing URLs
            # that expire or are bound to a short-lived portal session.
            stream_url = _resolve_stream_url(portal, channel["cmd"])
        except Exception as exc:
            raise HTTPException(status_code=502, detail=f"Could not resolve channel stream: {str(exc)[:350]}") from exc

        out_dir = HLS_ROOT / token
        if out_dir.exists() and not preserve_existing_segments:
            shutil.rmtree(out_dir, ignore_errors=True)
        out_dir.mkdir(parents=True, exist_ok=True)
        if preserve_existing_segments:
            _purge_old_segments(out_dir)
            # Force the new process to publish a fresh playlist after it has produced
            # a segment. Recent old TS segments remain available to in-flight clients.
            try:
                (out_dir / "index.m3u8").unlink(missing_ok=True)
            except OSError:
                pass
        headers = _headers(portal)
        # Include the Stalker bearer token for installations that protect media URLs with it.
        try:
            _, bearer = _get_token(portal)
            headers["Authorization"] = f"Bearer {bearer}"
        except Exception:
            pass
        ff_headers = "".join(f"{key}: {value}\r\n" for key, value in headers.items() if key.lower() in ("cookie", "user-agent", "x-user-agent", "authorization"))
        command = [
            FFMPEG_BIN, "-hide_banner", "-loglevel", "warning", "-nostdin", "-y",
            "-rw_timeout", "15000000", "-user_agent", UA,
            # Recover from short HTTP/TCP disconnects instead of exiting at the first gap.
            "-reconnect", "1", "-reconnect_streamed", "1", "-reconnect_at_eof", "1",
            "-reconnect_on_network_error", "1", "-reconnect_on_http_error", "5xx,408,429",
            "-reconnect_delay_max", "3", "-reconnect_max_retries", "5",
        ]
        if ff_headers:
            command += ["-headers", ff_headers]
        command += [
            "-i", stream_url,
            "-map", "0:v:0?", "-map", "0:a:0?", "-c", "copy",
            "-f", "hls", "-hls_time", str(HLS_TIME), "-hls_list_size", str(HLS_LIST_SIZE),
            # Do not append an old playlist after a source URL/session has been refreshed.
            # A larger list and delete threshold protect slower IPTV players from 404s.
            "-hls_flags", "delete_segments+omit_endlist+independent_segments",
            "-hls_delete_threshold", str(HLS_DELETE_THRESHOLD), "-hls_start_number_source", "epoch",
            "-hls_segment_filename", str(out_dir / "segment_%010d.ts"), str(out_dir / "index.m3u8"),
        ]
        log_handle = open(out_dir / "ffmpeg.log", "ab", buffering=0)
        started_mono = time.monotonic()
        try:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=log_handle, close_fds=True)
        except FileNotFoundError as exc:
            log_handle.close()
            raise HTTPException(status_code=500, detail="FFmpeg was not found in the container") from exc
        worker = {
            "process": process, "last_access": started_mono, "started_at": started_mono,
            "out_dir": out_dir, "log": log_handle, "channel_name": channel["name"],
        }
        stream_workers[token] = worker
        return worker


def _log_tail(worker):
    try:
        log_path = worker["out_dir"] / "ffmpeg.log"
        if log_path.exists():
            data = log_path.read_bytes()[-1800:].decode("utf-8", "replace")
            return data.strip()
    except Exception:
        pass
    return ""


def worker_cleanup_loop():
    while True:
        time.sleep(25)
        now = time.monotonic()
        expired = []
        with worker_lock:
            for token, worker in list(stream_workers.items()):
                if now - worker["last_access"] > IDLE_SECONDS:
                    _stop_worker(worker)
                    expired.append((token, worker["out_dir"]))
                    stream_workers.pop(token, None)
                else:
                    _purge_old_segments(worker["out_dir"])
        for _, directory in expired:
            shutil.rmtree(directory, ignore_errors=True)


@app.get("/health")
def health():
    return {"ok": True, "service": APP_NAME}


@app.get("/", response_class=HTMLResponse)
def home(_: str = Depends(admin_auth)):
    return HTMLResponse(INDEX_HTML)


@app.get("/api/portals")
def api_portals(_: str = Depends(admin_auth)):
    with db() as conn:
        rows = conn.execute("SELECT * FROM portals ORDER BY id DESC").fetchall()
    portals = [safe_public_portal(row) for row in rows]
    with db() as conn:
        for portal in portals:
            portal["channel_count"] = conn.execute("SELECT COUNT(*) FROM channels WHERE portal_id=?", (portal["id"],)).fetchone()[0]
    return portals


@app.post("/api/portals")
def api_add_portal(data: PortalIn, _: str = Depends(admin_auth)):
    url = normalize_portal_url(data.url)
    mac = data.mac.strip().upper()
    username = data.username.strip()
    password = data.password
    http_username = data.http_username.strip()
    http_password = data.http_password
    if mac and not re.fullmatch(r"[0-9A-F]{2}(?::[0-9A-F]{2}){5}", mac):
        raise HTTPException(status_code=400, detail="MAC must use format 00:1A:79:XX:XX:XX")
    if bool(username) != bool(password):
        raise HTTPException(status_code=400, detail="Enter both Stalker login and password, or leave both blank")
    if bool(http_username) != bool(http_password):
        raise HTTPException(status_code=400, detail="Enter both HTTP Basic username and password, or leave both blank")
    mac_generated = 0
    with db() as conn:
        if not mac:
            if not (username and password):
                raise HTTPException(status_code=400, detail="Enter a MAC address, or enter both Stalker login and password to use Ministra do_auth mode")
            # Login/password-only mode needs a client MAC for the initial Stalker handshake.
            # The portal's do_auth step binds this generated MAG-like identity to the account.
            for _ in range(100):
                raw = secrets.token_bytes(3)
                candidate = "00:1A:79:" + ":".join(f"{b:02X}" for b in raw)
                if not conn.execute("SELECT 1 FROM portals WHERE mac=?", (candidate,)).fetchone():
                    mac = candidate
                    mac_generated = 1
                    break
            if not mac:
                raise HTTPException(status_code=500, detail="Could not create a unique proxy MAC")
        cur = conn.execute("""INSERT INTO portals(name,url,mac,username,password,http_username,http_password,mac_generated)
                              VALUES(?,?,?,?,?,?,?,?)""",
                           (data.name.strip(), url, mac, username, password, http_username, http_password, mac_generated))
        portal_id = cur.lastrowid
    return {"ok": True, "id": portal_id}


@app.delete("/api/portals/{portal_id}")
def api_delete_portal(portal_id: int, _: str = Depends(admin_auth)):
    with worker_lock:
        with db() as conn:
            tokens = [r[0] for r in conn.execute("SELECT token FROM channels WHERE portal_id=?", (portal_id,)).fetchall()]
        for token in tokens:
            worker = stream_workers.pop(token, None)
            if worker:
                try:
                    worker["process"].terminate()
                    worker["log"].close()
                except Exception:
                    pass
                shutil.rmtree(worker["out_dir"], ignore_errors=True)
    with db() as conn:
        cur = conn.execute("DELETE FROM portals WHERE id=?", (portal_id,))
    with token_lock:
        portal_tokens.pop(portal_id, None)
    if cur.rowcount == 0:
        raise HTTPException(status_code=404, detail="Portal not found")
    return {"ok": True}


@app.post("/api/portals/{portal_id}/fetch")
def api_fetch_portal(portal_id: int, _: str = Depends(admin_auth)):
    try:
        count = fetch_live_channels(portal_id)
        return {"ok": True, "count": count, "playlist": f"{PUBLIC_BASE_URL}/stb/playlist.m3u?portal_id={portal_id}"}
    except Exception as exc:
        raise HTTPException(status_code=502, detail=str(exc)[:700]) from exc


@app.get("/api/channels")
def api_channels(portal_id: int | None = None, _: str = Depends(admin_auth)):
    return list_channels(portal_id)


def _m3u_escape(value):
    return str(value or "").replace("\r", " ").replace("\n", " ").replace('"', "'")


@app.get("/stb/playlist.m3u", response_class=PlainTextResponse)
def live_playlist(portal_id: int | None = None):
    channels = list_channels(portal_id)
    lines = ["#EXTM3U"]
    for channel in channels:
        name = _m3u_escape(channel["name"])
        logo = _m3u_escape(channel["logo"])
        group = _m3u_escape(channel["group_title"] or "Live TV")
        lines.append(f'#EXTINF:-1 tvg-name="{name}" tvg-logo="{logo}" group-title="{group}",{name}')
        lines.append(channel["url"])
    if len(lines) == 1:
        lines.append("# No Live TV channels loaded yet. Open the admin UI and click Fetch Live TV.")
    return PlainTextResponse("\n".join(lines) + "\n", media_type="audio/x-mpegurl", headers={"Cache-Control": "no-store"})


@app.get("/stb/mux/{token}.m3u8")
def mux_hls(token: str):
    if not re.fullmatch(r"\d{8}", token):
        raise HTTPException(status_code=404, detail="Unknown stream")
    worker = _worker_for(token)
    playlist = worker["out_dir"] / "index.m3u8"
    deadline = time.monotonic() + START_WAIT_SECONDS
    while time.monotonic() < deadline:
        if playlist.exists():
            try:
                body = playlist.read_text(encoding="utf-8", errors="replace")
                has_segments = "#EXTM3U" in body and any(
                    line.strip() and not line.strip().startswith("#") for line in body.splitlines()
                )
                # Existing playlists are removed on a worker restart. Checking age as
                # well prevents a partial/stale playlist from being handed to the player.
                if has_segments:
                    break
            except OSError:
                pass
        if worker["process"].poll() is not None:
            detail = _log_tail(worker)
            raise HTTPException(status_code=502, detail="FFmpeg exited before the HLS playlist was ready. " + detail[-500:])
        time.sleep(0.35)
    else:
        detail = _log_tail(worker)
        raise HTTPException(status_code=504, detail="Timed out waiting for upstream stream. " + detail[-500:])

    rewritten = []
    for line in body.splitlines():
        line = line.strip()
        if line and not line.startswith("#"):
            # FFmpeg emits only local TS segment names for this remux.
            if not re.fullmatch(r"segment_\d+\.ts", line):
                raise HTTPException(status_code=502, detail="Unexpected HLS segment path")
            line = f"/stb/segment/{token}/{line}"
        rewritten.append(line)
    with worker_lock:
        current = stream_workers.get(token)
        if current:
            current["last_access"] = time.monotonic()
    return Response("\n".join(rewritten) + "\n", media_type="application/vnd.apple.mpegurl", headers={"Cache-Control": "no-store, no-cache, must-revalidate", "Access-Control-Allow-Origin": "*"})


@app.get("/stb/segment/{token}/{filename}")
def hls_segment(token: str, filename: str):
    if not re.fullmatch(r"\d{8}", token) or not re.fullmatch(r"segment_\d+\.ts", filename):
        raise HTTPException(status_code=404, detail="Segment not found")
    with worker_lock:
        worker = stream_workers.get(token)
        if not worker:
            raise HTTPException(status_code=410, detail="Stream session expired; reload the playlist")
        worker["last_access"] = time.monotonic()
        path = worker["out_dir"] / filename
    if not path.is_file():
        raise HTTPException(status_code=404, detail="Segment not found or already expired")
    return Response(content=path.read_bytes(), media_type="video/mp2t", headers={"Cache-Control": "no-store", "Access-Control-Allow-Origin": "*"})


INDEX_HTML = r'''<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>STB Proxy by MIUCAST</title>
<style>
:root{font-family:Inter,Segoe UI,Arial,sans-serif;color:#202124;background:#f5f6f8}*{box-sizing:border-box}body{margin:0}.top{background:#c62828;color:#fff;padding:20px 24px}.top h1{font-size:22px;margin:0 0 5px}.top p{margin:0;color:#ffe8e8;font-size:13px}.wrap{max-width:1250px;margin:24px auto;padding:0 16px}.card{background:white;border:1px solid #e1e4e8;border-radius:12px;padding:18px;margin-bottom:18px;box-shadow:0 2px 8px #10182808}.card h2{font-size:17px;margin:0 0 16px}.grid{display:grid;grid-template-columns:repeat(6,minmax(0,1fr));gap:12px}.field{display:flex;flex-direction:column;gap:6px}.field label{font-size:12px;color:#5f6368}.field input{border:1px solid #d0d5dd;border-radius:7px;padding:10px;font-size:14px;min-width:0}.span2{grid-column:span 2}.actions{display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin-top:14px}button,.linkbtn{border:0;border-radius:7px;padding:9px 13px;background:#b71c1c;color:#fff;cursor:pointer;font-size:13px;text-decoration:none}button.secondary{background:#e9edf2;color:#252a31}button.danger{background:#fff0f0;color:#b42318}.muted{color:#6b7280;font-size:12px}.status{margin-top:12px;font-size:13px;white-space:pre-wrap}.portal{border:1px solid #eaecf0;border-radius:9px;padding:13px;margin-top:10px}.portalhead{display:flex;gap:12px;justify-content:space-between;align-items:center;flex-wrap:wrap}.portalhead strong{font-size:14px}.tablewrap{overflow:auto}table{border-collapse:collapse;width:100%;font-size:13px}th,td{text-align:left;border-bottom:1px solid #edf0f2;padding:10px 8px;vertical-align:middle}th{background:#fafafa;color:#555;font-weight:600;white-space:nowrap}.url{min-width:300px;max-width:440px;overflow-wrap:anywhere;font-family:Consolas,monospace;font-size:12px;color:#334155}.logo{width:42px;height:30px;object-fit:contain}input.search{width:100%;max-width:440px;padding:10px;border:1px solid #d0d5dd;border-radius:7px}.pill{background:#f2f4f7;padding:4px 7px;border-radius:5px;font-size:11px;color:#475467}.empty{padding:22px;color:#777;text-align:center}.topline{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}@media(max-width:800px){.grid{grid-template-columns:1fr 1fr}.span2{grid-column:span 2}.wrap{margin:14px auto}.top{padding:17px}}
</style></head><body><header class="top"><h1>STB Proxy <span style="font-weight:400">by MIUCAST</span></h1><p>Stalker Portal / Ministra Middleware · Live TV only · Docker · HLS remux</p></header><main class="wrap">
<section class="card"><h2>Add Stalker / Ministra Portal</h2><form id="portalForm"><div class="grid">
<div class="field span2"><label>Portal name</label><input name="name" required placeholder="My TV Portal"></div>
<div class="field span2"><label>Portal URL / base path</label><input name="url" required placeholder="http://portal.example/stalker_portal"></div>
<div class="field span2"><label>MAC address (for MAC mode)</label><input name="mac" placeholder="00:1A:79:XX:XX:XX"></div>
<div class="field span2"><label>Stalker login (optional)</label><input name="username" autocomplete="username" placeholder="Subscriber login"></div>
<div class="field span2"><label>Stalker password (optional)</label><input name="password" type="password" autocomplete="new-password" placeholder="Subscriber password"></div>
<div class="field span2"><label>HTTP Basic username (optional)</label><input name="http_username" autocomplete="username" placeholder="Web server auth username"></div>
<div class="field span2"><label>HTTP Basic password (optional)</label><input name="http_password" type="password" autocomplete="new-password" placeholder="Web server auth password"></div>
</div><div class="actions"><button type="submit">Save Portal</button><span class="muted">Use MAC mode, or leave MAC blank and enter both Stalker login/password for Ministra do_auth. HTTP Basic is a separate optional layer.</span></div></form><div id="formStatus" class="status"></div></section>
<section class="card"><div class="topline"><h2>Portals</h2><button class="secondary" onclick="loadPortals()">Refresh</button></div><div id="portals"><div class="empty">Loading portals…</div></div><div id="portalStatus" class="status"></div></section>
<section class="card"><div class="topline"><h2>Live TV Channels</h2><input id="search" class="search" placeholder="Filter by channel, group, or portal…" oninput="renderChannels()"></div><p class="muted">Only channels fetched from the Stalker <code>type=itv</code> endpoint are listed. Stream URL pattern: <code>/stb/mux/########.m3u8</code>.</p><div class="actions"><a class="linkbtn" href="/stb/playlist.m3u" target="_blank" rel="noopener">Open all-portals M3U</a><button class="secondary" onclick="loadChannels()">Refresh channels</button></div><div id="channels" class="tablewrap"><div class="empty">Fetch Live TV from a portal to populate this table.</div></div></section>
<section class="card"><h2>Notes</h2><div class="muted">Stream URLs are generated on demand. FFmpeg remuxes the authorized upstream channel into HLS using stream copy (no video transcoding). Stability safeguards enable HTTP reconnect, refresh create_link URLs after stalled workers, keep a larger HLS segment window, and clean old segments. Active streams use CPU/network resources. Stalker login/password uses the portal do_auth second-step when requested; a generated MAG-like client MAC is used if no MAC was provided. HTTP Basic Auth is a separate optional setting. The admin UI uses HTTP Basic Auth. Protect this service behind a trusted LAN, VPN, or HTTPS reverse proxy before exposing it to the public internet.</div></section>
</main><script>
let portals=[],channels=[];const $=id=>document.getElementById(id);const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
async function api(url,opts={}){const res=await fetch(url,{...opts,headers:{'Content-Type':'application/json',...(opts.headers||{})}});let data;try{data=await res.json()}catch{data=await res.text()}if(!res.ok)throw new Error(data.detail||data||('HTTP '+res.status));return data}
async function loadPortals(){try{portals=await api('/api/portals');renderPortals()}catch(e){$('portalStatus').textContent=e.message}}
function renderPortals(){const root=$('portals');if(!portals.length){root.innerHTML='<div class="empty">No portal configured yet.</div>';return}root.innerHTML=portals.map(p=>`<div class="portal"><div class="portalhead"><div><strong>${esc(p.name)}</strong> <span class="pill">${p.channel_count} Live TV</span><div class="muted">${esc(p.url)} · MAC ${esc(p.mac)}${p.mac_generated?' (generated for login/password mode)':''}${p.username?' · Stalker login/password':''}${p.http_basic_enabled?' · HTTP Basic':''}${p.endpoint?' · API '+esc(p.endpoint):''}</div></div><div class="actions" style="margin:0"><button onclick="fetchLive(${p.id})">Fetch Live TV</button><button class="secondary" onclick="openPlaylist(${p.id})">Portal M3U</button><button class="danger" onclick="deletePortal(${p.id})">Delete</button></div></div></div>`).join('')}
async function fetchLive(id){$('portalStatus').textContent='Fetching Live TV channels…';try{const r=await api('/api/portals/'+id+'/fetch',{method:'POST'});$('portalStatus').textContent=`Loaded ${r.count} Live TV channels. Playlist: ${r.playlist}`;await loadPortals();await loadChannels()}catch(e){$('portalStatus').textContent='Fetch failed: '+e.message}}
function openPlaylist(id){window.open('/stb/playlist.m3u?portal_id='+id,'_blank','noopener')}
async function deletePortal(id){if(!confirm('Delete this portal and its cached channel list?'))return;try{await api('/api/portals/'+id,{method:'DELETE'});await loadPortals();await loadChannels();$('portalStatus').textContent='Portal deleted.'}catch(e){$('portalStatus').textContent=e.message}}
$('portalForm').addEventListener('submit',async e=>{e.preventDefault();const f=new FormData(e.target);const payload=Object.fromEntries(f.entries());$('formStatus').textContent='Saving portal…';try{await api('/api/portals',{method:'POST',body:JSON.stringify(payload)});e.target.reset();$('formStatus').textContent='Portal saved. Click Fetch Live TV to test the connection and load channels.';await loadPortals()}catch(err){$('formStatus').textContent='Could not save: '+err.message}});
async function loadChannels(){try{channels=await api('/api/channels');renderChannels()}catch(e){$('channels').innerHTML='<div class="empty">'+esc(e.message)+'</div>'}}
function renderChannels(){const q=$('search').value.toLowerCase();const rows=channels.filter(c=>[c.name,c.group_title,c.portal_name,c.channel_id].join(' ').toLowerCase().includes(q));if(!rows.length){$('channels').innerHTML='<div class="empty">No matching channels. Add a portal and click Fetch Live TV.</div>';return} $('channels').innerHTML='<table><thead><tr><th>Logo</th><th>Channel</th><th>Group</th><th>Portal</th><th>HLS URL</th><th></th></tr></thead><tbody>'+rows.map(c=>`<tr><td>${c.logo?`<img class="logo" src="${esc(c.logo)}" onerror="this.style.display='none'">`:''}</td><td><strong>${esc(c.name)}</strong><div class="muted">ID ${esc(c.channel_id)}</div></td><td>${esc(c.group_title)}</td><td>${esc(c.portal_name)}</td><td class="url">${esc(c.url)}</td><td><button class="secondary" onclick="copyUrl('${esc(c.url)}')">Copy</button></td></tr>`).join('')+'</tbody></table>'}
async function copyUrl(url){try{await navigator.clipboard.writeText(url)}catch{prompt('Copy stream URL:',url)}}
loadPortals().then(loadChannels);
</script></body></html>'''

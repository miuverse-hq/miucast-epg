# TVH Proxy — TVHeadend to HLS/M3U8

Dockerized Node.js + FFmpeg proxy. Adds an HTTP/RTSP/RTMP/UDP/RTP/TCP/SRT (where supported by the bundled FFmpeg build) source and produces a live HLS playlist at:

`http://IP:7701/tvh/mux/1234.m3u8`

The four-digit ID is randomly assigned when a session is created. HLS segments are served below `/tvh/mux/1234/`.

## Start on Docker Desktop / Linux

1. Extract this ZIP into a directory, open a terminal in that directory.
2. Copy `.env.example` to `.env` and change `UI_PASSWORD`.
3. Start the service:

   ```bash
   docker compose up -d --build
   ```

4. Open `http://IP:7701` in a browser. Default credentials when `.env` is not configured: `admin` / `change-me-now`.
5. Enter a source URL and press **สร้าง M3U8 Session**. Copy the generated URL to VLC or an IPTV player.

To view logs:

```bash
docker compose logs -f tvh-proxy
```

Optional stability tuning in `docker-compose.yml` environment: `WATCHDOG_INTERVAL_MS` (default 10000), `STALL_TIMEOUT_MS` (default 60000), and `STARTUP_GRACE_MS` (default 90000). Use the defaults initially.

To update/rebuild:

```bash
docker compose up -d --build
```

To stop:

```bash
docker compose down
```

Session configuration and HLS files are stored in the persistent Docker volume `tvh_proxy_data`; `docker compose down` does not remove it. `docker compose down -v` removes the volume and saved data.

## Example TVHeadend source URLs

Replace host/IDs with your own values. The exact URL and stream profile must be allowed by your TVHeadend access rules.

- Whole mux: `http://TVH-IP:9981/stream/mux/MUX_UUID`
- Channel UUID: `http://TVH-IP:9981/stream/channel/CHANNEL_UUID?profile=pass`
- Channel ID: `http://TVH-IP:9981/stream/channelid/CHANNEL_ID?profile=pass`
- Service: `http://TVH-IP:9981/stream/service/SERVICE_UUID`

If TVHeadend requires authentication, fill in the source username and password in the UI. When using Docker Desktop, remember that `localhost` inside the container is the container itself; use a reachable LAN IP or `host.docker.internal` for a service on the Windows host.

## Modes

- **Stream Copy / Remux** (default): low CPU use, preserves source codecs; best when those codecs fit MPEG-TS HLS.
- **Transcode**: converts video to H.264 and audio to AAC for better player compatibility, with substantially higher CPU usage. It does not guarantee every subtitle, unusual codec or malformed stream can be converted.

Stability settings: target segment duration 4 seconds, 15-segment playlist (~60 seconds), plus 15 additional retained segments on disk to protect slower players. HTTP inputs retry transient network failures; protocol read timeout is 30 seconds. A watchdog checks playlist progress every 10 seconds and restarts FFmpeg if output stalls for 60 seconds (or fails to produce a playlist within 90 seconds). During a restart, the previous playlist and segments are preserved instead of being deleted, so compatible players can continue through brief source interruptions. The HTTP M3U8 endpoint returns `503` if no playlist exists yet, so clients should retry briefly. These settings reduce interruptions but cannot prevent cuts caused by the TVHeadend server, tuner, network, codec, or client itself.

## Coverage and limitations

"All TVHeadend links" cannot be guaranteed for every possible protocol and codec. This implementation accepts direct FFmpeg input URLs using common stream protocols, but exact support depends on the FFmpeg build and the source being reachable from the container. TVHeadend HTTP endpoints for mux/channel/service are supported when they return readable stream bytes. HTSP is a separate TVHeadend protocol and is not directly consumable as an FFmpeg URL in this build; use an HTTP streaming URL. DRM/encrypted content that the source does not decrypt is not bypassed. The proxy does not remove DRM or defeat access controls.

The admin interface/API uses HTTP Basic Authentication; HLS URLs intentionally remain unauthenticated for compatibility with IPTV players. Keep the service on a trusted LAN, set a strong admin password, and do not expose the port directly to the public internet without additional access controls. Input URLs and source credentials are stored in the persistent Docker volume; protect access to the volume.


## Compatibility hotfix

This build removes the `-reconnect_max_retries` option because some FFmpeg builds (including older distro packages) reject it with `Unrecognized option`. FFmpeg uses its built-in reconnect policy for HTTP inputs; if FFmpeg exits, the supervisor restarts it automatically.

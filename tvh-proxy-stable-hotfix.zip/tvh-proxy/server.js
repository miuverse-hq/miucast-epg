'use strict';

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawn } = require('child_process');

const PORT = Number(process.env.PORT || 7701);
const DATA_DIR = process.env.DATA_DIR || '/data';
const SESSIONS_DIR = path.join(DATA_DIR, 'sessions');
const STATE_FILE = path.join(DATA_DIR, 'sessions.json');
const FFMPEG_BIN = process.env.FFMPEG_BIN || 'ffmpeg';
const UI_USERNAME = process.env.UI_USERNAME || 'admin';
const UI_PASSWORD = process.env.UI_PASSWORD || 'change-me-now';
const WATCHDOG_INTERVAL_MS = Math.max(5000, Number(process.env.WATCHDOG_INTERVAL_MS || 10000));
const STALL_TIMEOUT_MS = Math.max(20000, Number(process.env.STALL_TIMEOUT_MS || 60000));
const STARTUP_GRACE_MS = Math.max(30000, Number(process.env.STARTUP_GRACE_MS || 90000));
const PUBLIC_DIR = path.join(__dirname, 'public');
const ALLOWED_PROTOCOLS = new Set([
  'http:', 'https:', 'rtsp:', 'rtmp:', 'rtmps:', 'rtmpe:', 'rtmpt:',
  'rtmpts:', 'udp:', 'rtp:', 'tcp:', 'srt:', 'rist:', 'mms:', 'mmsh:',
  'mmst:', 'ftp:', 'ftps:'
]);

fs.mkdirSync(SESSIONS_DIR, { recursive: true });
const sessions = new Map();
let shuttingDown = false;

function sha256(value) {
  return crypto.createHash('sha256').update(String(value), 'utf8').digest();
}

function constantTimeEqual(a, b) {
  return crypto.timingSafeEqual(sha256(a), sha256(b));
}

function isAuthorized(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Basic ')) return false;
  let decoded;
  try { decoded = Buffer.from(header.slice(6), 'base64').toString('utf8'); }
  catch { return false; }
  const split = decoded.indexOf(':');
  if (split < 0) return false;
  const user = decoded.slice(0, split);
  const pass = decoded.slice(split + 1);
  return constantTimeEqual(user, UI_USERNAME) && constantTimeEqual(pass, UI_PASSWORD);
}

function send(res, status, body, contentType = 'application/json; charset=utf-8', headers = {}) {
  const payload = Buffer.isBuffer(body) ? body : Buffer.from(String(body));
  res.writeHead(status, {
    'Content-Type': contentType,
    'Content-Length': payload.length,
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'Referrer-Policy': 'same-origin',
    ...headers
  });
  res.end(payload);
}

function json(res, status, data, headers = {}) {
  send(res, status, JSON.stringify(data), 'application/json; charset=utf-8', headers);
}

function safeEqualText(value, max) {
  return typeof value === 'string' && value.length <= max;
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString('utf8');
      if (body.length > 1024 * 1024) {
        reject(new Error('Request body is too large (max 1 MB).'));
        req.destroy();
      }
    });
    req.on('end', () => {
      try { resolve(body ? JSON.parse(body) : {}); }
      catch { reject(new Error('Invalid JSON body.')); }
    });
    req.on('error', reject);
  });
}

function validateSourceUrl(raw) {
  if (typeof raw !== 'string' || !raw.trim() || raw.length > 8192) {
    throw new Error('กรุณาระบุ Source URL (ความยาวไม่เกิน 8,192 ตัวอักษร)');
  }
  let u;
  try { u = new URL(raw.trim()); }
  catch { throw new Error('Source URL ไม่ถูกต้อง'); }
  if (!ALLOWED_PROTOCOLS.has(u.protocol)) {
    throw new Error(`ไม่รองรับ protocol ${u.protocol || '(ไม่ระบุ)'}; ใช้ HTTP(S), RTSP, RTMP, UDP/RTP, TCP, SRT หรือโปรโตคอลสตรีมที่ FFmpeg ใน image นี้รองรับ`);
  }
  if (!u.hostname) throw new Error('Source URL ต้องมี host');
  return u;
}

function normalizeSessionInput(body) {
  const name = typeof body.name === 'string' ? body.name.trim() : '';
  if (!name || name.length > 80) throw new Error('ชื่อ Stream ต้องมีความยาว 1–80 ตัวอักษร');
  const parsedUrl = validateSourceUrl(body.url);
  const username = typeof body.username === 'string' ? body.username : '';
  const password = typeof body.password === 'string' ? body.password : '';
  const userAgent = typeof body.userAgent === 'string' ? body.userAgent.trim() : '';
  const referer = typeof body.referer === 'string' ? body.referer.trim() : '';
  if (!safeEqualText(username, 256) || !safeEqualText(password, 512)) throw new Error('Username หรือ Password ยาวเกินไป');
  if (!safeEqualText(userAgent, 512)) throw new Error('User-Agent ยาวเกินไป');
  if (!safeEqualText(referer, 2048) || /[\r\n]/.test(referer)) throw new Error('Referer ไม่ถูกต้อง');
  if (referer) {
    let ref;
    try { ref = new URL(referer); } catch { throw new Error('Referer ต้องเป็น URL ที่ถูกต้อง'); }
    if (!['http:', 'https:'].includes(ref.protocol)) throw new Error('Referer ต้องใช้ HTTP หรือ HTTPS');
  }
  const mode = body.mode === 'transcode' ? 'transcode' : 'copy';
  if ((username || password) && ['http:', 'https:', 'rtsp:', 'rtmp:', 'rtmps:', 'rtmpt:', 'rtmpts:'].includes(parsedUrl.protocol)) {
    parsedUrl.username = username;
    parsedUrl.password = password;
  }
  return {
    name,
    url: parsedUrl.toString(),
    username: '',
    password: '',
    userAgent,
    referer,
    mode
  };
}

function persist() {
  const data = [...sessions.values()].map(s => ({
    id: s.id,
    name: s.name,
    url: s.url,
    mode: s.mode,
    userAgent: s.userAgent,
    referer: s.referer,
    createdAt: s.createdAt,
    desiredRunning: Boolean(s.desiredRunning)
  }));
  const tempFile = `${STATE_FILE}.tmp`;
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), { mode: 0o600 });
  fs.renameSync(tempFile, STATE_FILE);
}

function createSessionId() {
  for (let i = 0; i < 10000; i += 1) {
    const id = String(crypto.randomInt(0, 10000)).padStart(4, '0');
    if (!sessions.has(id)) return id;
  }
  throw new Error('ไม่มีเลข Session ว่าง กรุณาลบ Session ที่ไม่ใช้งานก่อน');
}

function sessionDir(id) {
  return path.join(SESSIONS_DIR, id);
}

function safeDeleteSessionFiles(id) {
  const dir = sessionDir(id);
  if (path.dirname(dir) === SESSIONS_DIR) fs.rmSync(dir, { recursive: true, force: true });
}

function publicSession(s) {
  const logs = s.logs || [];
  return {
    id: s.id,
    name: s.name,
    mode: s.mode,
    status: s.status,
    createdAt: s.createdAt,
    desiredRunning: Boolean(s.desiredRunning),
    path: `/tvh/mux/${s.id}.m3u8`,
    ready: fs.existsSync(path.join(sessionDir(s.id), 'index.m3u8')),
    error: s.error || '',
    lastLog: logs.slice(-1)[0] || ''
  };
}

function addLog(s, text) {
  if (!s.logs) s.logs = [];
  for (const line of String(text).split(/\r?\n/)) {
    const clean = line.trim();
    if (!clean) continue;
    s.logs.push(`${new Date().toISOString()} ${clean}`);
  }
  if (s.logs.length > 250) s.logs.splice(0, s.logs.length - 250);
}

function buildFfmpegArgs(s) {
  const dir = sessionDir(s.id);
  // Larger input queues help absorb short bursts of jitter without overrunning FFmpeg's demux thread.
  const args = [
    '-hide_banner', '-nostdin', '-loglevel', 'warning', '-y',
    '-fflags', '+genpts+discardcorrupt',
    '-thread_queue_size', '4096',
    '-rw_timeout', '30000000'
  ];
  let protocol = '';
  try { protocol = new URL(s.url).protocol; } catch { /* validated on create/load */ }
  if (protocol === 'http:' || protocol === 'https:') {
    // Retry transient network/HTTP errors and keep live HTTP streams alive after brief drops.
    args.push(
      '-reconnect', '1',
      '-reconnect_at_eof', '1',
      '-reconnect_streamed', '1',
      '-reconnect_on_network_error', '1',
      '-reconnect_on_http_error', '408,429,5xx',
      '-reconnect_delay_max', '10'
    );
  }
  if (s.userAgent) args.push('-user_agent', s.userAgent);
  if (s.referer) args.push('-headers', `Referer: ${s.referer}\r\n`);
  args.push('-i', s.url, '-map', '0:v:0?', '-map', '0:a?');
  if (s.mode === 'transcode') {
    args.push('-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency', '-crf', '23', '-c:a', 'aac', '-b:a', '128k', '-ac', '2');
  } else {
    args.push('-c', 'copy');
  }
  args.push(
    '-max_muxing_queue_size', '4096',
    '-f', 'hls',
    '-hls_time', '4',
    // Keep a 60-second live window and extra segments on disk for slower IPTV players.
    '-hls_list_size', '15',
    '-hls_delete_threshold', '15',
    // append_list preserves the live timeline when FFmpeg reconnects; do not erase segments on every restart.
    '-hls_flags', 'delete_segments+append_list+omit_endlist+independent_segments+program_date_time',
    '-hls_segment_filename', path.join(dir, 'segment_%06d.ts'),
    '-hls_base_url', `/tvh/mux/${s.id}/`,
    path.join(dir, 'index.m3u8')
  );
  return args;
}

function stopWatchdog(s) {
  if (s.watchdogTimer) clearInterval(s.watchdogTimer);
  s.watchdogTimer = null;
  if (s.forceKillTimer) clearTimeout(s.forceKillTimer);
  s.forceKillTimer = null;
}

function startWatchdog(s, child) {
  stopWatchdog(s);
  s.startedAtMs = Date.now();
  s.lastProgressAtMs = s.startedAtMs;
  // Baseline an existing playlist so a restart doesn't mistake stale output for fresh progress.
  try { s.lastPlaylistMtimeMs = fs.statSync(path.join(sessionDir(s.id), 'index.m3u8')).mtimeMs; }
  catch { s.lastPlaylistMtimeMs = 0; }
  s.stallRestarting = false;
  s.watchdogTimer = setInterval(() => {
    if (s.proc !== child || !s.desiredRunning || shuttingDown) {
      stopWatchdog(s);
      return;
    }

    const playlistPath = path.join(sessionDir(s.id), 'index.m3u8');
    let mtimeMs = 0;
    try { mtimeMs = fs.statSync(playlistPath).mtimeMs; } catch { /* playlist not ready yet */ }
    const now = Date.now();
    if (mtimeMs && mtimeMs !== s.lastPlaylistMtimeMs) {
      s.lastPlaylistMtimeMs = mtimeMs;
      s.lastProgressAtMs = now;
      if (s.status === 'starting' || s.status === 'restarting') {
        s.status = 'running';
        s.error = '';
        persist();
      }
      // If the stream was healthy for a while, don't keep a high restart backoff forever.
      if (now - s.startedAtMs >= 180000) s.restartCount = 0;
      return;
    }

    const hasProducedPlaylist = Boolean(s.lastPlaylistMtimeMs);
    const elapsed = now - (hasProducedPlaylist ? s.lastProgressAtMs : s.startedAtMs);
    const limit = hasProducedPlaylist ? STALL_TIMEOUT_MS : STARTUP_GRACE_MS;
    if (elapsed >= limit && !s.stallRestarting) {
      s.stallRestarting = true;
      s.status = 'restarting';
      s.error = `No HLS playlist progress for ${Math.round(elapsed / 1000)} seconds; restarting FFmpeg`;
      addLog(s, `[watchdog] ${s.error}`);
      persist();
      try { child.kill('SIGTERM'); } catch { /* child may already have exited */ }
      s.forceKillTimer = setTimeout(() => {
        if (s.proc === child) {
          addLog(s, '[watchdog] FFmpeg did not stop after SIGTERM; sending SIGKILL');
          try { child.kill('SIGKILL'); } catch { /* ignore */ }
        }
      }, 5000);
      if (s.forceKillTimer.unref) s.forceKillTimer.unref();
    }
  }, WATCHDOG_INTERVAL_MS);
  if (s.watchdogTimer.unref) s.watchdogTimer.unref();
}

function startProcess(s) {
  if (shuttingDown || !s.desiredRunning || !sessions.has(s.id)) return;
  if (s.proc) return;
  clearTimeout(s.restartTimer);
  s.restartTimer = null;
  // Intentionally keep the previous playlist and segments while restarting. Deleting them here
  // causes a visible freeze/404 to every player during a brief source disconnect.
  fs.mkdirSync(sessionDir(s.id), { recursive: true });
  s.status = s.restartCount > 0 ? 'restarting' : 'starting';
  s.error = '';
  const args = buildFfmpegArgs(s);
  addLog(s, `Starting FFmpeg mode=${s.mode}`);
  try {
    const child = spawn(FFMPEG_BIN, args, { stdio: ['ignore', 'ignore', 'pipe'] });
    s.proc = child;
    startWatchdog(s, child);
    child.stderr.on('data', chunk => addLog(s, chunk.toString('utf8')));
    child.on('error', err => {
      addLog(s, `FFmpeg spawn error: ${err.message}`);
      s.error = err.message;
    });
    child.on('close', (code, signal) => {
      stopWatchdog(s);
      if (s.proc === child) s.proc = null;
      addLog(s, `FFmpeg exited code=${code} signal=${signal || 'none'}`);
      if (!sessions.has(s.id)) return;
      if (s.desiredRunning && !shuttingDown) {
        s.status = 'restarting';
        s.error = code === 0 ? '' : (s.logs || []).slice(-5).join('\n');
        s.restartCount = (s.restartCount || 0) + 1;
        persist();
        s.restartTimer = setTimeout(() => startProcess(s), Math.min(15000, 3000 + Math.min(s.restartCount, 4) * 1000));
        if (s.restartTimer.unref) s.restartTimer.unref();
      } else {
        // A non-zero exit is expected when an operator deliberately stops FFmpeg with SIGTERM.
        // Do not leave a misleading error badge on a session that was intentionally stopped.
        s.status = 'stopped';
        s.error = '';
      }
      persist();
    });
    // The status changes to running once the watchdog observes a refreshed HLS playlist.
    persist();
  } catch (err) {
    stopWatchdog(s);
    s.proc = null;
    s.status = 'error';
    s.error = err.message;
    addLog(s, `Unable to start FFmpeg: ${err.message}`);
    persist();
  }
}

function stopProcess(s) {
  s.desiredRunning = false;
  clearTimeout(s.restartTimer);
  s.restartTimer = null;
  stopWatchdog(s);
  const child = s.proc;
  if (!child) {
    s.status = 'stopped';
    persist();
    return Promise.resolve();
  }
  s.status = 'stopping';
  persist();
  return new Promise(resolve => {
    let finished = false;
    const finish = () => {
      if (finished) return;
      finished = true;
      clearTimeout(killTimer);
      if (s.proc === child) s.proc = null;
      s.status = 'stopped';
      persist();
      resolve();
    };
    child.once('close', finish);
    try { child.kill('SIGTERM'); } catch { /* process already exited */ }
    const killTimer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch { /* ignored */ }
      finish();
    }, 4000);
  });
}

function contentType(file) {
  if (file.endsWith('.html')) return 'text/html; charset=utf-8';
  if (file.endsWith('.m3u8')) return 'application/vnd.apple.mpegurl';
  if (file.endsWith('.ts')) return 'video/mp2t';
  return 'application/octet-stream';
}

function serveFile(req, res, file, isPlaylist = false) {
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) {
    return send(res, isPlaylist ? 503 : 404, isPlaylist ? 'Stream is starting; retry shortly.' : 'Not found', 'text/plain; charset=utf-8', isPlaylist ? { 'Retry-After': '2', 'Cache-Control': 'no-store' } : {});
  }
  const stat = fs.statSync(file);
  res.writeHead(200, {
    'Content-Type': contentType(file),
    'Content-Length': stat.size,
    'Cache-Control': isPlaylist ? 'no-cache, no-store, must-revalidate' : 'public, max-age=2',
    'Access-Control-Allow-Origin': '*',
    'X-Content-Type-Options': 'nosniff'
  });
  if (req.method === 'HEAD') return res.end();
  const stream = fs.createReadStream(file);
  stream.on('error', () => { if (!res.headersSent) res.writeHead(500); res.end(); });
  stream.pipe(res);
}

function requireJson(req, res) {
  if (!req.headers['content-type'] || !req.headers['content-type'].includes('application/json')) {
    json(res, 415, { error: 'Content-Type must be application/json' });
    return false;
  }
  return true;
}

async function handleApi(req, res, url) {
  if (req.method === 'GET' && url.pathname === '/api/sessions') {
    return json(res, 200, [...sessions.values()].map(publicSession));
  }

  if (req.method === 'POST' && url.pathname === '/api/sessions') {
    if (!requireJson(req, res)) return;
    try {
      const body = await readJson(req);
      const input = normalizeSessionInput(body);
      const id = createSessionId();
      const s = {
        id, ...input,
        createdAt: new Date().toISOString(),
        status: 'stopped', desiredRunning: true,
        proc: null, restartTimer: null, watchdogTimer: null, forceKillTimer: null,
        restartCount: 0, startedAtMs: 0, lastProgressAtMs: 0, lastPlaylistMtimeMs: 0,
        stallRestarting: false, logs: [], error: ''
      };
      // A newly allocated ID may have stale orphan files after an unclean host shutdown.
      safeDeleteSessionFiles(id);
      sessions.set(id, s);
      persist();
      startProcess(s);
      return json(res, 201, publicSession(s));
    } catch (err) {
      return json(res, 400, { error: err.message || 'ไม่สามารถสร้าง Session ได้' });
    }
  }

  const match = url.pathname.match(/^\/api\/sessions\/(\d{4})(?:\/(start|stop|logs))?$/);
  if (match) {
    const [, id, action] = match;
    const s = sessions.get(id);
    if (!s) return json(res, 404, { error: 'ไม่พบ Session นี้' });
    if (req.method === 'GET' && action === 'logs') return json(res, 200, { id, logs: s.logs || [] });
    if (req.method === 'POST' && action === 'start') {
      if (!s.proc) {
        s.desiredRunning = true;
        s.restartCount = 0;
        s.error = '';
        s.status = 'starting';
        persist();
        startProcess(s);
      }
      return json(res, 200, publicSession(s));
    }
    if (req.method === 'POST' && action === 'stop') {
      await stopProcess(s);
      return json(res, 200, publicSession(s));
    }
    if (req.method === 'DELETE' && !action) {
      await stopProcess(s);
      sessions.delete(id);
      safeDeleteSessionFiles(id);
      persist();
      return json(res, 200, { ok: true, id });
    }
  }

  return json(res, 404, { error: 'API route not found' });
}

const server = http.createServer(async (req, res) => {
  let url;
  try { url = new URL(req.url, `http://${req.headers.host || 'localhost'}`); }
  catch { return send(res, 400, 'Bad Request', 'text/plain; charset=utf-8'); }

  if (url.pathname === '/healthz') return json(res, 200, { ok: true });

  // HLS media URLs are intentionally public so IPTV players do not need HTTP Basic Auth.
  const playlistMatch = url.pathname.match(/^\/tvh\/mux\/(\d{4})\.m3u8$/);
  if (playlistMatch && (req.method === 'GET' || req.method === 'HEAD')) {
    const [, id] = playlistMatch;
    if (!sessions.has(id)) return send(res, 404, 'Unknown stream', 'text/plain; charset=utf-8');
    return serveFile(req, res, path.join(sessionDir(id), 'index.m3u8'), true);
  }
  const segmentMatch = url.pathname.match(/^\/tvh\/mux\/(\d{4})\/(segment_\d+\.ts)$/);
  if (segmentMatch && (req.method === 'GET' || req.method === 'HEAD')) {
    const [, id, filename] = segmentMatch;
    if (!sessions.has(id)) return send(res, 404, 'Unknown stream', 'text/plain; charset=utf-8');
    return serveFile(req, res, path.join(sessionDir(id), filename), false);
  }

  if (url.pathname.startsWith('/api/') || url.pathname === '/' || url.pathname === '/index.html') {
    if (!isAuthorized(req)) {
      return send(res, 401, 'Authentication required', 'text/plain; charset=utf-8', { 'WWW-Authenticate': 'Basic realm="TVH Proxy Admin", charset="UTF-8"', 'Cache-Control': 'no-store' });
    }
  }

  if (url.pathname.startsWith('/api/')) {
    try { return await handleApi(req, res, url); }
    catch (err) { return json(res, 500, { error: err.message || 'Internal server error' }); }
  }

  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    const html = path.join(PUBLIC_DIR, 'index.html');
    return serveFile(req, res, html, false);
  }
  return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
});

function loadPersistedSessions() {
  if (!fs.existsSync(STATE_FILE)) return;
  try {
    const raw = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    if (!Array.isArray(raw)) return;
    for (const item of raw) {
      if (!item || !/^\d{4}$/.test(item.id || '') || sessions.has(item.id)) continue;
      try { validateSourceUrl(item.url); } catch { continue; }
      sessions.set(item.id, {
        id: item.id,
        name: String(item.name || `Stream ${item.id}`).slice(0, 80),
        url: item.url,
        mode: item.mode === 'transcode' ? 'transcode' : 'copy',
        userAgent: String(item.userAgent || '').slice(0, 512),
        referer: String(item.referer || '').slice(0, 2048),
        createdAt: item.createdAt || new Date().toISOString(),
        desiredRunning: Boolean(item.desiredRunning),
        status: item.desiredRunning ? 'starting' : 'stopped',
        proc: null, restartTimer: null, watchdogTimer: null, forceKillTimer: null,
        restartCount: 0, startedAtMs: 0, lastProgressAtMs: 0, lastPlaylistMtimeMs: 0,
        stallRestarting: false, logs: [], error: ''
      });
    }
  } catch (err) {
    console.error('Could not load saved sessions:', err.message);
  }
}

function shutdown() {
  if (shuttingDown) return;
  shuttingDown = true;
  for (const s of sessions.values()) {
    s.desiredRunning = false;
    clearTimeout(s.restartTimer);
    stopWatchdog(s);
    if (s.proc) {
      try { s.proc.kill('SIGTERM'); } catch { /* ignored */ }
    }
  }
  try { persist(); } catch { /* ignored during shutdown */ }
  setTimeout(() => server.close(() => process.exit(0)), 250).unref();
  setTimeout(() => process.exit(0), 3000).unref();
}

loadPersistedSessions();
server.listen(PORT, '0.0.0.0', () => {
  console.log(`TVH Proxy listening on :${PORT}`);
  console.log(`Admin username: ${UI_USERNAME}; set UI_PASSWORD to a strong value`);
  for (const s of sessions.values()) if (s.desiredRunning) startProcess(s);
});

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
